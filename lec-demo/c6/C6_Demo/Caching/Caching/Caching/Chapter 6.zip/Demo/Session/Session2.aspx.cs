using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Session2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["BasketCount"] != null)
        {
            if ((int)Session["BasketCount"] >= 1)
            {
                Response.Write("<h3>Thank you. You have purchased " +
                Session["BasketCount"] + " polo shirt(s).</h3>");
            }
            else
                Response.Write("<h3>Thank you for drop by....See u</h3>");
        }
        else
        {
            Response.Write("<h3>Your basket is empty!</h3>");
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("session1.aspx");
    }
}
