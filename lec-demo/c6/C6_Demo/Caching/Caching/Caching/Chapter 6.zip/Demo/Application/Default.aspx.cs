using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblWelcome.Text = Application["Welcome"].ToString();
        lblDisplayDate.Text = "You log on to our site on " + Session["Time"].ToString();
        lblCount.Text = "There are " + Application["intVisitors"].ToString() + " user(s) online.";
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
    }
}
