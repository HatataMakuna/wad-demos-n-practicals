using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["LastSearch"].Value  != null)
            lblSearch.Text = Request.Cookies["LastSearch"].Value;
        
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        HttpCookie myCookie = new HttpCookie("LastSearch", txtSearch.Text);
        //HttpCookie myCookie = new HttpCookie("LastSearch");
        //myCookie.Value = txtSearch.Text;
        myCookie.Expires = DateTime.Now.AddDays(7);
        Response.Cookies.Add(myCookie);
    }
}
        
